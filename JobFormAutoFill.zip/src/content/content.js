(async function () {

  try {
    // Fail gracefully if not in an extension context (e.g. testing)
    if (
      !window.chrome ||
      !window.chrome.storage ||
      !window.chrome.storage.local
    ) {
      console.warn("JobForm AutoFill: chrome.storage is not available.");
      return;
    }

    const result = await chrome.storage.local.get(["profileData"]);
    let profileData = result.profileData;

    if (!profileData) {
      const syncResult = await chrome.storage.sync.get(["profileData"]);
      if (syncResult.profileData) profileData = syncResult.profileData;
    }

    if (!profileData) {
      console.warn("JobForm AutoFill: No profile data found.");
      return;
    }

    // Helper to format text for better matching
    const normalize = (str) =>
      (str || "")
        .replace(/[-_]/g, " ")
        .replace(/\s+/g, " ")
        .toLowerCase()
        .trim();

    function setNativeValue(element, value) {
      let prototype = Object.getPrototypeOf(element);
      let descriptor = Object.getOwnPropertyDescriptor(prototype, "value");

      while (!descriptor && prototype !== null) {
        prototype = Object.getPrototypeOf(prototype);
        if (prototype)
          descriptor = Object.getOwnPropertyDescriptor(prototype, "value");
      }

      try {
        if (descriptor && descriptor.set) {
          descriptor.set.call(element, value);
        } else {
          element.value = value;
        }
      } catch (e) {
        console.warn(`JobForm AutoFill: Failed to set value "${value}" on element. Trying fallback.`, e);
        
        // Fallback for year/month fields complaining about full date strings
        if (typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value)) {
           try {
              let extractedValue = value;
              const idStr = (element.id || '').toLowerCase();
              const nameStr = (element.name || '').toLowerCase();
              const typeStr = (element.type || '').toLowerCase();
              
              const isMonthSelect = idStr.includes('month') || nameStr.includes('month');
              const isYearSelect = idStr.includes('year') || nameStr.includes('year') || typeStr === 'number';
              
              if (isMonthSelect) {
                 const monthStr = value.substring(5, 7);
                 extractedValue = monthStr.startsWith('0') ? monthStr.substring(1) : monthStr; 
              } else if (isYearSelect) {
                 extractedValue = value.substring(0, 4);
              }
              
              if (descriptor && descriptor.set) {
                descriptor.set.call(element, extractedValue);
              } else {
                element.value = extractedValue;
              }
           } catch (err) {
              console.warn("JobForm AutoFill: Date fallback also failed.", err);
           }
        }
      }

      element.dispatchEvent(new Event("input", { bubbles: true }));
      element.dispatchEvent(new Event("change", { bubbles: true }));
      element.dispatchEvent(new Event("blur", { bubbles: true }));
    }

    async function setFileValue(element, fileData) {
      try {
        console.log(`JobForm AutoFill: Attaching file "${fileData.name}"`);
        const res = await fetch(fileData.data);
        const blob = await res.blob();
        // Preserves the exact original filename and lastModified date
        const file = new File([blob], fileData.name, {
          type: fileData.type,
          lastModified: fileData.lastModified || Date.now(),
        });
        const dataTransfer = new DataTransfer();
        dataTransfer.items.add(file);
        element.files = dataTransfer.files;
        element.dispatchEvent(new Event("change", { bubbles: true }));
      } catch (e) {
        console.error("JobForm AutoFill: Failed to set file", e);
      }
    }

    const fieldMatchers = [
      {
        keys: ["authorized"],
        regex:
          /authorized.*work|legally.*authorized|right.*to.*work|eligible.*to.*work/i,
      },
      { keys: ["sponsorship"], regex: /sponsorship|require.*visa|sponsor/i },
      { keys: ["firstName"], regex: /first.*name|fname|given.*name/i },
      { keys: ["lastName"], regex: /last.*name|lname|surname|family.*name/i },
      {
        keys: ["firstName", "lastName"],
        regex: /\bname\b|full.*name/i,
        combiner: (d) => `${d.firstName || ""} ${d.lastName || ""}`.trim(),
      },
      { keys: ["email"], regex: /email|e-mail/i },
      { keys: ["country"], regex: /country|location|residence/i, combiner: (d) => ({ isCountry: true, name: d.country, code: d.countryCode, dialCode: d.countryDialCode }) },
      { keys: ["phone"], regex: /phone|tel|mobile|cell/i },
      { keys: ["timeZone"], regex: /time.*zone/i },
      { keys: ["startDate"], regex: /start.*date|date.*available/i },
      { keys: ["linkedin"], regex: /linkedin/i },
      { keys: ["github"], regex: /github/i },
      { keys: ["portfolio"], regex: /portfolio|website|url/i },
      { keys: ["gender"], regex: /gender|sex/i },
      { keys: ["hispanic"], regex: /hispanic|latino/i },
      { keys: ["race"], regex: /race|ethnicity/i },
      { keys: ["veteran"], regex: /veteran/i },
      { keys: ["disability"], regex: /disability/i },
      { keys: ["school"], regex: /school|university|college|institution/i },
      { keys: ["degree"], regex: /degree/i },
      { keys: ["discipline"], regex: /discipline|major|field.*study/i },
      {
        keys: ["specialField1"],
        regex: /cover.*letter|about.*me|message|additional.*info|project|why.*interested/i,
      },
      { keys: ["specialField2"], regex: /references|role|applying.*for/i },
      { keys: ["specialField3"], regex: /notes/i },
      { keys: ["resumeFile"], regex: /resume|cv/i, isFile: true },
      { keys: ["coverLetterFile"], regex: /cover.*letter/i, isFile: true },
    ];

    // Attempt to fill a specific input given a value
    async function attemptFill(
      input,
      valueToSet,
      isFile = false,
      fileData = null,
    ) {
      if (isFile && fileData) {
        await setFileValue(input, fileData);
        return true;
      }

      if (!valueToSet) return false;

      let isCountry = false;
      let countryName = "";
      let countryCode = "";
      let countryDialCode = "";

      if (typeof valueToSet === "object" && valueToSet.isCountry) {
        isCountry = true;
        countryName = valueToSet.name;
        countryCode = valueToSet.code;
        countryDialCode = valueToSet.dialCode;
        valueToSet = countryName; // Default fallback for normalized strings in other handlers
      }

      const valLower = normalize(valueToSet);

      // Handle Select Native
      if (input.tagName === "SELECT") {
        const options = Array.from(input.options);
        
        let matchingOption = null;
        if (isCountry) {
          // 1. Exact match name or value
          matchingOption = options.find((opt) => normalize(opt.text) === valLower || normalize(opt.value) === valLower);
          
          // 2. Contains name (e.g. "United States (+1)")
          if (!matchingOption) {
            matchingOption = options.find((opt) => normalize(opt.text).includes(valLower));
          }

          // 3. Dial Code (for phone country selectors)
          if (!matchingOption && countryDialCode) {
            matchingOption = options.find((opt) => opt.text.includes(countryDialCode) || opt.value.includes(countryDialCode));
          }
          
          // 4. ISO Code (e.g. "US")
          if (!matchingOption && countryCode) {
            matchingOption = options.find((opt) => normalize(opt.text) === normalize(countryCode) || normalize(opt.value) === normalize(countryCode));
          }
        } else {
          matchingOption = options.find(
            (opt) => normalize(opt.text) === valLower || normalize(opt.value) === valLower,
          );
          if (!matchingOption) {
            matchingOption = options.find(
              (opt) => normalize(opt.text).startsWith(valLower) || normalize(opt.value).startsWith(valLower),
            );
          }
        }

        if (matchingOption) {
          input.value = matchingOption.value;
          input.dispatchEvent(new Event("change", { bubbles: true }));
          input.dispatchEvent(new Event("input", { bubbles: true }));
          return true;
        }
        return false;
      }
      
      // Handle React Select Comboboxes and other custom dropdowns
      else if (
        input.tagName === "DIV" ||
        input.getAttribute("role") === "combobox" ||
        (input.className && input.className.includes("select__input")) ||
        input.getAttribute("aria-haspopup") === "listbox"
      ) {
        // Try to find the actual clickable element
        const controlWrapper = input.closest('div[class*="control"]') || 
                             input.closest('div[class*="container"]') || 
                             input;
        
        const toggleButton = controlWrapper.querySelector(
          ".select__indicators button, .select__indicators svg, svg[class*='Chevron'], svg[class*='chevron'], .iti__arrow, .selected-flag, [class*='arrow'], [class*='indicator']"
        );

        const targetToClick = toggleButton || controlWrapper || input;
        
        // Trigger opening
        ["mousedown", "mouseup", "click"].forEach(type => {
          targetToClick.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window }));
        });

        // Small synchronous delay to let the menu render
        await new Promise(r => setTimeout(r, 400));

        const allOptions = Array.from(
          document.querySelectorAll(
            '[id*="-option-"], [class*="-option"], [role="option"], [role="menuitem"], .notion-selectable-hover-menu-item, [role="menu"] div[role="button"], .iti__country, .country-list li, li.country'
          )
        ).filter(el => {
          const style = window.getComputedStyle(el);
          return style.display !== 'none' && style.visibility !== 'hidden';
        });

        let matchingOption = null;
        if (isCountry) {
          // 1. Exact match ISO Code (Most reliable if data-country-code exists)
          if (countryCode) {
            matchingOption = allOptions.find((opt) =>
              opt.getAttribute('data-country-code') === countryCode.toLowerCase()
            );
          }

          // 2. Exact match Name
          if (!matchingOption) {
            matchingOption = allOptions.find((opt) => normalize(opt.textContent) === valLower);
          }

          // 3. Includes Name (e.g., "United States (+1)")
          if (!matchingOption) {
            matchingOption = allOptions.find((opt) => normalize(opt.textContent).includes(valLower));
          }

          // 4. Dial Code (Fallback, risky because multiple countries share +1)
          if (!matchingOption && countryDialCode) {
            matchingOption = allOptions.find((opt) => {
              const text = opt.textContent;
              const dial = opt.getAttribute('data-dial-code');
              return dial === countryDialCode.replace('+', '') || text.includes(countryDialCode);
            });
          }
        } else {
          matchingOption = allOptions.find((opt) => normalize(opt.textContent) === valLower);
          if (!matchingOption) {
            matchingOption = allOptions.find((opt) => normalize(opt.textContent).startsWith(valLower));
          }
        }

        if (matchingOption) {
          ["mousedown", "mouseup", "click"].forEach(type => {
            matchingOption.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window }));
          });
          
          // Force a blur/change on the underlying input if we can find it
          const innerInput = input.querySelector('input') || (input.tagName === 'INPUT' ? input : null);
          if (innerInput) {
             innerInput.dispatchEvent(new Event('change', { bubbles: true }));
             innerInput.dispatchEvent(new Event('blur', { bubbles: true }));
          }
          
          return true;
        } else {
          // Close menu if no match found
          document.body.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true, view: window }));
          return false;
        }
      }
      // Handle Custom Button Groups and Radio/Checkbox
      else if (
        input.type === "radio" ||
        input.type === "checkbox" ||
        input.type === "hidden" ||
        input.tabIndex === -1
      ) {
        // Custom button groups (e.g., Ashby Yes/No)
        const container = input.parentElement;
        if (container) {
          const buttons = Array.from(container.querySelectorAll("button"));
          if (buttons.length > 0) {
            const matchingBtn = buttons.find(
              (btn) =>
                normalize(btn.textContent) === valLower ||
                normalize(btn.textContent).includes(valLower),
            );
            if (matchingBtn) {
              ["mousedown", "mouseup", "click"].forEach(type => {
                matchingBtn.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window }));
              });
              return true;
            }
          }
        }

        if (input.type === "radio" || input.type === "checkbox") {
          const labelText = normalize(
            input.closest("label")?.textContent ||
              input.nextElementSibling?.textContent ||
              input.parentElement?.textContent ||
              "",
          );
          if (labelText.includes(valLower)) {
            input.checked = true;
            input.dispatchEvent(new Event("change", { bubbles: true }));
            input.dispatchEvent(new Event("input", { bubbles: true }));
            return true;
          }
        }
      }
      // Handle Standard Inputs
      else {
        setNativeValue(input, valueToSet);
        return true;
      }
      return false;
    }

    // --- Automatic Pass ---
    let filledCount = 0;
    const rawInputs = document.querySelectorAll(
      'input:not([type="hidden"]):not([type="submit"]):not([type="button"]), textarea, select, div[role="combobox"], div[role="button"], div[class*="select__"], div[class*="-select-"], div[class="select"]',
    );

    const validInputs = Array.from(rawInputs).filter((input) => {
      // Exclude visibly hidden inputs (e.g. react-select inner inputs, honeypots, or file inputs with 0 opacity)
      const style = window.getComputedStyle(input);
      let isHidden = false;
      if (
        style.display === "none" ||
        style.visibility === "hidden" ||
        style.opacity === "0" ||
        input.className?.includes("visually-hidden") ||
        input.className?.includes("select__input") // Often the hidden inner input of a custom combobox
      ) {
        isHidden = true;
      }
      
      // Also check if immediate parent is hidden (e.g. iti__search-input in closed dropdown)
      if (!isHidden && input.parentElement) {
        const parentStyle = window.getComputedStyle(input.parentElement);
        if (parentStyle.display === "none" || parentStyle.visibility === "hidden" || parentStyle.opacity === "0") {
            isHidden = true;
        }
      }

      if (isHidden) return false;

      if (input.tagName === "DIV") {
        const role = input.getAttribute("role");
        const className = (input.className || "").toLowerCase();
        
        // Stricter heuristics for custom dropdown DIVs
        const isLikelySelectClass = /\b(select\b|select__input|-select-)/.test(className) &&
                                   !className.includes("notion-selectable") &&
                                   !className.includes("select__container") &&
                                   !className.includes("select__control") &&
                                   !className.includes("select__value-container") &&
                                   !className.includes("select__placeholder") &&
                                   !className.includes("select__indicators") &&
                                   !className.includes("select__menu");
        
        const isCombobox = role === "combobox";
        const isTestIdProp = input.getAttribute("data-testid") === "property-value";
        const hasListboxPopup = input.getAttribute("aria-haspopup") === "listbox" || input.getAttribute("aria-haspopup") === "menu";
        
        // Must explicitly act as a combobox or have a known select class
        if (!isCombobox && !hasListboxPopup && !isLikelySelectClass && !isTestIdProp) {
          return false;
        }
      }
      return true;
    });

    for (const input of validInputs) {

      if (
        input.type !== "file" &&
        input.type !== "checkbox" &&
        input.type !== "radio" &&
        input.value &&
        input.value.trim() !== ""
      )
        continue;
      if (input.type === "file" && input.files && input.files.length > 0)
        continue;

      const name = input.name || "";
      const id = input.id || "";
      const placeholder = input.placeholder || "";
      const ariaLabel = input.getAttribute("aria-label") || "";

      let ariaLabelledByText = "";
      const ariaLabelledBy = input.getAttribute("aria-labelledby");
      if (ariaLabelledBy) {
        const ids = ariaLabelledBy.split(/\s+/);
        for (const labelId of ids) {
          const labelEl = document.getElementById(labelId);
          if (labelEl) {
             ariaLabelledByText += " " + labelEl.textContent;
          }
        }
      }

      let labelText = "";
      if (id) {
        const label = document.querySelector(`label[for="${id}"]`);
        if (label) labelText = label.textContent;
      }
      if (!labelText && name) {
        const label = document.querySelector(`label[for="${name}"]`);
        if (label) labelText = label.textContent;
      }
      if (!labelText) {
        const parentLabel = input.closest("label");
        if (parentLabel) labelText = parentLabel.textContent;
      }

      if (!labelText) {
        let current = input;
        for (let i = 0; i < 3; i++) {
          if (!current) break;
          const prev = current.previousElementSibling;
          if (prev && (prev.tagName.match(/^H[1-6]$/) || prev.tagName === 'LABEL' || prev.tagName === 'DIV')) {
            // Check if this previous element looks like a label/heading
            const text = prev.textContent.trim();
            if (text && text.length < 100) { // arbitrary limit so we don't grab paragraphs
              labelText = text;
              break;
            }
          }
          current = current.parentElement;
        }
      }

      // Check fieldsets/legends for radio groups (aggressive matching)
      let groupText = "";
      const fieldset = input.closest("fieldset");
      if (fieldset) {
        const legend = fieldset.querySelector("legend");
        if (legend) groupText = legend.textContent;
      }

      let siblingText = "";
      const prevEl = input.previousElementSibling;
      if (
        prevEl &&
        (prevEl.tagName === "LABEL" ||
          prevEl.tagName === "DIV" ||
          prevEl.tagName === "SPAN")
      ) {
        siblingText = prevEl.textContent;
      }

      let containerText = "";
      if (!labelText) {
        let container = input.parentElement;
        for (let i = 0; i < 5; i++) {
          if (container) {
            const cName = (container.className || "").toLowerCase();
            if (
              cName.includes("field") ||
              cName.includes("group") ||
              cName.includes("entry") ||
              cName.includes("question")
            ) {
              // Clone to avoid getting all text from child inputs
              const clone = container.cloneNode(true);
              const inputsToDel = clone.querySelectorAll(
                "input, select, textarea, button",
              );
              inputsToDel.forEach((el) => el.remove());
              const text = clone.textContent.trim();
              if (text) {
                containerText = text;
                break;
              }
            }
            container = container.parentElement;
          }
        }
      }

      let combinedText = normalize(
        `${name} ${id} ${placeholder} ${ariaLabel} ${ariaLabelledByText} ${labelText} ${groupText} ${siblingText} ${containerText}`,
      );

      // Heuristic for global hidden file inputs (e.g. React Dropzone in Notion)
      if (input.type === "file" && combinedText.trim() === "") {
        const hasResumeText = /resume|cv/i.test(document.body.innerText);
        const allFileInputs = document.querySelectorAll('input[type="file"]');
        if (allFileInputs.length === 1 && hasResumeText) {
          combinedText = "resume"; // force match
        }
      }

      // Greenhouse / Standard Consent Checkbox
      if (
        input.type === "checkbox" &&
        combinedText.includes("consent") &&
        (combinedText.includes("process") ||
          combinedText.includes("retention") ||
          combinedText.includes("gdpr"))
      ) {
        input.checked = true;
        input.dispatchEvent(new Event("change", { bubbles: true }));
        filledCount++;
        continue;
      }

      // Matcher checks
      for (const matcher of fieldMatchers) {
        if (matcher.isFile && input.type !== "file") continue;
        if (!matcher.isFile && input.type === "file") continue;

        if (matcher.regex.test(combinedText)) {
          if (matcher.isFile) {
            const fileData = profileData[matcher.keys[0]];
            if (fileData) {
              await attemptFill(input, null, true, fileData);
              filledCount++;
            }
            break;
          } else {
            let valueToSet = matcher.combiner
              ? matcher.combiner(profileData)
              : profileData[matcher.keys[0]];
            // For radio buttons, we are looping through ALL radios. If the combined text matches the QUESTION (e.g. veteran),
            // attemptFill will check if the specific radio's label matches the ANSWER (profileData value).
            if (valueToSet) {
              if (typeof valueToSet === "string" && valueToSet.trim() !== "") {
                const filled = await attemptFill(input, valueToSet);
                if (filled) filledCount++;
              } else if (typeof valueToSet === "object" && valueToSet.isCountry) {
                const filled = await attemptFill(input, valueToSet);
                if (filled) filledCount++;
              }
            }
            break;
          }
        }
      }
      
      // Add a small delay between each successful fill to prevent UI race conditions (e.g. overlapping dropdown menus)
      await new Promise(r => setTimeout(r, 100));
    }
    console.log(
      `JobForm AutoFill: Automatically filled ${filledCount} fields.`,
    );

    // --- Injected UI (Manual Override) ---
    class JobFormPopupManager {
      constructor() {
        this.container = document.createElement("div");
        this.container.id = "jf-popup-manager-root";
        document.body.appendChild(this.container);
        this.shadow = this.container.attachShadow({ mode: "closed" });

        this.shadow.innerHTML = `
          <style>
            .popup {
              position: absolute; width: 320px; max-height: 400px;
              background: #1e1e1e; color: #fff;
              border: 1px solid #444; border-radius: 8px;
              box-shadow: 0 10px 25px rgba(0,0,0,0.5);
              z-index: 2147483647; overflow-y: auto;
              font-family: system-ui, -apple-system, sans-serif; font-size: 13px;
              display: none; flex-direction: column;
              padding: 6px 0px;
            }
            .popup.show { display: flex; }
            .header { padding: 10px; border-bottom: 1px solid #333; font-weight: bold; background: #252525; position: sticky; top: 0; z-index: 2; display: flex; justify-content: space-between; }
            .close-btn { cursor: pointer; color: #aaa; }
            .close-btn:hover { color: #fff; }
            .row {
              display: flex; justify-content: space-between; align-items: center;
              padding: 8px 10px; border-bottom: 1px solid #333;
            }
            .row:hover { background: #2a2a2a; }
            .label { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: #ccc; min-height: 18px; line-height: 18px; display: block; }
            .actions { display: flex; gap: 6px; margin-left: 10px; }
            .btn {
              background: #3b82f6; color: white; border: none; padding: 4px 8px; border-radius: 4px; cursor: pointer; font-size: 11px;
              display: inline-flex; align-items: center; justify-content: center;
            }
            .btn.copy { background: #10b981; font-size: calc(11px + 0.1em); }
            .btn.fill svg { width: 14px; height: 14px; pointer-events: none; }
            .btn:hover { opacity: 0.8; }
            .btn:active { transform: scale(0.95); }
          </style>
          <div class="popup" id="jf-popup">
            <div class="header">
              <span>AutoFill Manual Override</span>
              <span class="close-btn" id="jf-close">✖</span>
            </div>
            <div id="jf-content"></div>
          </div>
        `;

        this.popupEl = this.shadow.getElementById("jf-popup");
        this.contentEl = this.shadow.getElementById("jf-content");
        this.currentInput = null;

        this.shadow
          .getElementById("jf-close")
          .addEventListener("click", () => this.hide());
        document.addEventListener("click", (e) => {
          if (!e.composedPath().includes(this.container)) this.hide();
        });
      }

      show(x, y, input, anchorRect) {
        this.currentInput = input;
        this.contentEl.innerHTML = "";

        const textFields = [
          { key: "firstName", label: "First Name" },
          { key: "lastName", label: "Last Name" },
          { key: "email", label: "Email" },
          { key: "phone", label: "Phone" },
          { key: "country", label: "Country", combiner: (d) => ({ isCountry: true, name: d.country, code: d.countryCode, dialCode: d.countryDialCode }) },
          { key: "timeZone", label: "Time Zone" },
          { key: "startDate", label: "Start Date" },
          { key: "linkedin", label: "LinkedIn" },
          { key: "github", label: "GitHub" },
          { key: "portfolio", label: "Portfolio" },
          { key: "gender", label: "Gender" },
          { key: "hispanic", label: "Hispanic/Latino" },
          { key: "race", label: "Race" },
          { key: "veteran", label: "Veteran Status" },
          { key: "disability", label: "Disability" },
          { key: "authorized", label: "Authorized" },
          { key: "sponsorship", label: "Sponsorship" },
          { key: "specialField1", label: "Custom 1" },
          { key: "specialField2", label: "Custom 2" },
          { key: "specialField3", label: "Custom 3" },
        ];

        textFields.forEach((field) => {
          const val = field.combiner ? field.combiner(profileData) : profileData[field.key];
          
          let displayVal = val;
          if (val && typeof val === 'object' && val.isCountry) {
            displayVal = val.name;
          }

          if (!displayVal) return;

          const row = document.createElement("div");
          row.className = "row";
          row.innerHTML = `
            <div class="label" title="${displayVal}"><strong>${field.label}:</strong> ${displayVal}</div>
            <div class="actions">
              <button class="btn copy" title="Copy to clipboard">📋</button>
              <button class="btn fill" title="Fill into field"><svg xmlns="http://www.w3.org/2000/svg" xml:space="preserve" style="fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2;filter: drop-shadow(-1px -1px 0px #A6A09B);" viewBox="0 0 20 20"><path d="M592.961 603.655 466.769 729.846H288.308c0-98.561 79.9-178.461 178.461-178.461a178.46 178.46 0 0 1 126.192 52.27" style="fill:#9bff58" transform="translate(-16.155 -30.897)scale(.05603)"/><path d="M645.231 729.846H466.769l126.192-126.191a178.46 178.46 0 0 1 52.27 126.191" style="fill:#3eddff" transform="translate(-16.155 -30.897)scale(.05603)"/><path d="M288.308 729.846h356.923c0 98.562-79.9 178.462-178.462 178.462s-178.461-79.9-178.461-178.462" style="fill:#f88" transform="translate(-16.155 -30.897)scale(.05603)"/></svg></button>
            </div>
          `;

          row.querySelector(".copy").addEventListener("click", (e) => {
            e.stopPropagation();
            navigator.clipboard.writeText(displayVal);
            const btn = e.target;
            btn.textContent = "✓";
            setTimeout(() => (btn.textContent = "📋"), 1500);
          });

          row.querySelector(".fill").addEventListener("click", async (e) => {
            e.stopPropagation();
            await attemptFill(this.currentInput, val);
            this.hide();
          });

          this.contentEl.appendChild(row);
        });

        this.popupEl.classList.add("show");

        // Smart positioning
        const popupRect = this.popupEl.getBoundingClientRect();
        const spaceBelow = window.innerHeight - anchorRect.bottom;

        if (
          spaceBelow < popupRect.height &&
          anchorRect.top > popupRect.height
        ) {
          // Show above
          this.popupEl.style.top = `${anchorRect.top + window.scrollY - popupRect.height - 5}px`;
        } else {
          // Show below
          this.popupEl.style.top = `${anchorRect.bottom + window.scrollY + 5}px`;
        }

        // Prevent horizontal overflow
        let leftPos = anchorRect.left + window.scrollX;
        if (leftPos + 320 > document.body.scrollWidth) {
          leftPos = document.body.scrollWidth - 330;
        }
        this.popupEl.style.left = `${Math.max(10, leftPos)}px`;
      }

      hide() {
        this.popupEl.classList.remove("show");
        this.currentInput = null;
      }
    }

    const popupManager = new JobFormPopupManager();

    // Inject buttons
    for (const input of validInputs) {
      // Don't inject on files or buttons
      if (
        input.type === "file" ||
        input.type === "hidden" ||
        input.type === "submit" ||
        input.dataset.skipQuickEdit === "true"
      )
        continue;

      const btnNode = document.createElement("div");
      btnNode.style.display = "inline-block";
      const shadow = btnNode.attachShadow({ mode: "open" });
      shadow.innerHTML = `
        <style>
          .btn {
            display: inline-flex; align-items: center; justify-content: center;
            width: 20px; height: 20px; cursor: pointer;
            margin-right: 6px; vertical-align: middle;
            user-select: none;
            transition: transform 0.1s;
          }
          .btn:hover { transform: scale(1.2); }
          .btn svg { width: 100%; height: 100%; pointer-events: none; }
        </style>
        <div class="btn" title="JobForm AutoFill Override">
          <svg xmlns="http://www.w3.org/2000/svg" xml:space="preserve" style="fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2;filter: drop-shadow(-1px -1px 0px #A6A09B);" viewBox="0 0 20 20"><path d="M592.961 603.655 466.769 729.846H288.308c0-98.561 79.9-178.461 178.461-178.461a178.46 178.46 0 0 1 126.192 52.27" style="fill:#9bff58" transform="translate(-16.155 -30.897)scale(.05603)"/><path d="M645.231 729.846H466.769l126.192-126.191a178.46 178.46 0 0 1 52.27 126.191" style="fill:#3eddff" transform="translate(-16.155 -30.897)scale(.05603)"/><path d="M288.308 729.846h356.923c0 98.562-79.9 178.462-178.462 178.462s-178.461-79.9-178.461-178.462" style="fill:#f88" transform="translate(-16.155 -30.897)scale(.05603)"/></svg>
        </div>
      `;

      // Inject before the label if it exists, otherwise before the input
      const id = input.id;
      let label = id ? document.querySelector(`label[for="${id}"]`) : null;
      if (!label) label = input.closest("label");

      let targetEl = label || input;

      targetEl.parentNode.insertBefore(btnNode, targetEl);

      shadow.querySelector(".btn").addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        popupManager.show(
          e.clientX,
          e.clientY,
          input,
          btnNode.getBoundingClientRect(),
        );
      });
    }
  } catch (error) {
    console.error("JobForm AutoFill Error:", error);
  }
})();
